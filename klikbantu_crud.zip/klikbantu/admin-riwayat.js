function filterData(type, btn) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    document.querySelectorAll('.transaction-row').forEach(row => {
        const match = type === 'all' || row.getAttribute('data-type') === type;
        row.style.display = match ? '' : 'none';
    });
}
