<?php
session_start();
include 'includes/koneksi.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$action = $_POST['action'] ?? '';

function uploadGambar($file, $conn, $id = null) {
    if (empty($file['name'])) return null;

    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) { header("Location: admin.php?error=invalid_file"); exit(); }
    if ($file['size'] > 5 * 1024 * 1024) { header("Location: admin.php?error=file_too_large"); exit(); }

    $namaFile = 'campaign_' . time() . '_' . rand(100, 999) . '.' . $ext;
    $tujuan   = 'assets/img/campaigns/' . $namaFile;

    if (!is_dir('assets/img/campaigns')) mkdir('assets/img/campaigns', 0755, true);
    if (!move_uploaded_file($file['tmp_name'], $tujuan)) { header("Location: admin.php?error=upload_failed"); exit(); }

    if ($id) {
        $q = $conn->prepare("SELECT gambar FROM campaigns WHERE id = ?");
        $q->bind_param("i", $id);
        $q->execute();
        $old = $q->get_result()->fetch_assoc();
        if (!empty($old['gambar']) && file_exists('assets/img/campaigns/' . $old['gambar'])) {
            unlink('assets/img/campaigns/' . $old['gambar']);
        }
    }
    return $namaFile;
}

// ============================================================
// ADD
// ============================================================
if ($action === 'add') {
    $nama      = trim($_POST['nama']);
    $kategori  = $_POST['kategori'];
    $target    = (int) $_POST['target_dana'];
    $deskripsi = trim($_POST['deskripsi']);
    $status    = $_POST['status'] ?? 'active';
    $id_user   = (int) $_SESSION['user_id'];

    if (empty($nama) || empty($kategori) || $target <= 0 || empty($deskripsi)) {
        header("Location: admin.php?error=empty_fields"); exit();
    }

    $gambar = uploadGambar($_FILES['gambar'], $conn) ?? '';

    // bind: i=id_user, s=gambar, s=nama, s=kategori, i=target, s=deskripsi, s=status  => "isssiss"
    $stmt = $conn->prepare("INSERT INTO campaigns (id_user, gambar, nama, kategori, target_dana, deskripsi, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssiss", $id_user, $gambar, $nama, $kategori, $target, $deskripsi, $status);

    if ($stmt->execute()) {
        header("Location: admin.php?success=campaign_added");
    } else {
        header("Location: admin.php?error=db_error");
    }
    exit();
}

// ============================================================
// EDIT
// ============================================================
if ($action === 'edit') {
    $id        = (int) $_POST['id'];
    $nama      = trim($_POST['nama']);
    $kategori  = $_POST['kategori'];
    $target    = (int) $_POST['target_dana'];
    $deskripsi = trim($_POST['deskripsi']);
    $status    = $_POST['status'] ?? 'active';

    if ($id <= 0 || empty($nama) || empty($kategori) || $target <= 0 || empty($deskripsi)) {
        header("Location: admin.php?error=empty_fields"); exit();
    }

    $gambarBaru = uploadGambar($_FILES['gambar'], $conn, $id);

    if ($gambarBaru) {
        // s=nama, s=kategori, i=target, s=deskripsi, s=status, s=gambar, i=id => "ssisssi"
        $stmt = $conn->prepare("UPDATE campaigns SET nama=?, kategori=?, target_dana=?, deskripsi=?, status=?, gambar=? WHERE id=?");
        $stmt->bind_param("ssisssi", $nama, $kategori, $target, $deskripsi, $status, $gambarBaru, $id);
    } else {
        // s=nama, s=kategori, i=target, s=deskripsi, s=status, i=id => "ssissi"
        $stmt = $conn->prepare("UPDATE campaigns SET nama=?, kategori=?, target_dana=?, deskripsi=?, status=? WHERE id=?");
        $stmt->bind_param("ssissi", $nama, $kategori, $target, $deskripsi, $status, $id);
    }

    if ($stmt->execute()) {
        header("Location: admin.php?success=campaign_updated");
    } else {
        header("Location: admin.php?error=db_error");
    }
    exit();
}

header("Location: admin.php");
exit();
