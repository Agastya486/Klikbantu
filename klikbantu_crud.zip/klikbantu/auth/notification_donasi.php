<?php
require_once dirname(__FILE__) . '/../vendor/autoload.php';
include '../includes/koneksi.php';

\Midtrans\Config::$serverKey    = 'Mid-server-MxSvXM264NSr02QIbgbctfge';
\Midtrans\Config::$isProduction = false;

try {
    $notif       = new \Midtrans\Notification();
    $status      = $notif->transaction_status;
    $order_id    = $notif->order_id;
    $snap_token  = $notif->token ?? '';
    $gross_amount = (int) $notif->gross_amount;

    // Ambil custom fields
    $id_campaign = (int) $notif->custom_field1;
    $id_user     = (int) $notif->custom_field2;
    $is_anonim   = (int) $notif->custom_field3;

    if ($status === 'settlement' || $status === 'capture') {
        // Update status donasi jadi success berdasarkan snap_token
        $upd = $conn->prepare("UPDATE donations SET status_pembayaran='success', metode=? WHERE snap_token=? AND id_campaign=? AND id_user=?");
        $metode = $notif->payment_type ?? 'unknown';
        $upd->bind_param("ssii", $metode, $snap_token, $id_campaign, $id_user);
        $upd->execute();

        // Update dana_terkumpul di campaign
        $updCampaign = $conn->prepare("UPDATE campaigns SET dana_terkumpul = dana_terkumpul + ? WHERE id = ?");
        $updCampaign->bind_param("ii", $gross_amount, $id_campaign);
        $updCampaign->execute();

        http_response_code(200);
        error_log("Donasi Rp $gross_amount ke campaign #$id_campaign berhasil.");

    } elseif ($status === 'expire' || $status === 'cancel' || $status === 'deny') {
        $upd = $conn->prepare("UPDATE donations SET status_pembayaran='failed' WHERE snap_token=?");
        $upd->bind_param("s", $snap_token);
        $upd->execute();
        http_response_code(200);
    }

} catch (Exception $e) {
    error_log("Webhook Donasi Error: " . $e->getMessage());
    http_response_code(500);
}
